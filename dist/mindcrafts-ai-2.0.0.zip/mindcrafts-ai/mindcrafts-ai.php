<?php
/**
 * Plugin Name:       MindCrafts AI for Elementor
 * Description:       Transform Elementor with AI power — build complete pages from a single prompt, manage widgets, layouts, templates, WooCommerce, SEO, and more via MCP tools for AI agents like Claude and Cursor.
 * Version:           2.0.0
 * Requires at least: 6.8
 * Tested up to:      6.8
 * Requires PHP:      7.4
 * Author:            MindCrafts AI
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mindcrafts-ai
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'MINDCRAFTS_AI_VERSION', '2.0.0' );
define( 'MINDCRAFTS_AI_DIR', plugin_dir_path( __FILE__ ) );
define( 'MINDCRAFTS_AI_URL', plugin_dir_url( __FILE__ ) );
define( 'MINDCRAFTS_AI_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Loads plugin translations.
 *
 * @since 2.0.0
 */
function mindcrafts_ai_load_textdomain(): void {
	load_plugin_textdomain(
		'mindcrafts-ai',
		false,
		dirname( MINDCRAFTS_AI_BASENAME ) . '/languages'
	);
}
add_action( 'plugins_loaded', 'mindcrafts_ai_load_textdomain', 5 );

/**
 * Boots the admin page even when runtime dependencies are missing.
 *
 * @since 2.0.0
 */
function mindcrafts_ai_boot_admin(): void {
	static $booted = false;

	if ( $booted || ! is_admin() ) {
		return;
	}

	require_once MINDCRAFTS_AI_DIR . 'includes/admin/class-admin.php';

	$admin = new MindCrafts_AI_Admin();
	$admin->init();

	$booted = true;

	do_action( 'mindcrafts_ai_admin_initialized' );
}

/**
 * Checks that all required dependencies are available.
 *
 * @since 2.0.0
 *
 * @return bool True if all dependencies are met.
 */
function mindcrafts_ai_check_dependencies(): bool {
	$missing = array();

	// Elementor must be active.
	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = 'Elementor';
	}

	// MCP Adapter must be active.
	if ( ! class_exists( '\WP\MCP\Core\McpAdapter' ) ) {
		$missing[] = 'WordPress MCP Adapter';
	}

	// WordPress Abilities API must be available.
	if ( ! function_exists( 'wp_register_ability' ) ) {
		$missing[] = 'WordPress Abilities API (bundled with WordPress 6.9+ or installed separately)';
	}

	if ( ! empty( $missing ) ) {
		add_action( 'admin_notices', function () use ( $missing ) {
			echo '<div class="notice notice-error"><p>';
			echo wp_kses(
				sprintf(
					/* translators: %s: comma-separated list of missing dependencies */
					__( 'MindCrafts AI for Elementor requires the following to be installed and active: <strong>%s</strong>', 'mindcrafts-ai' ),
					esc_html( implode( ', ', $missing ) )
				),
				array( 'strong' => array() )
			);
			echo '</p></div>';
		} );

		return false;
	}

	return true;
}

/**
 * Initializes the plugin.
 *
 * Hooked to `plugins_loaded` at priority 20 to ensure Elementor and
 * other dependencies are loaded first.
 *
 * @since 2.0.0
 */
function mindcrafts_ai_init(): void {
	mindcrafts_ai_boot_admin();

	if ( ! mindcrafts_ai_check_dependencies() ) {
		return;
	}

	// Load class files.
	require_once MINDCRAFTS_AI_DIR . 'includes/class-id-generator.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/class-elementor-data.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/class-element-factory.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/schemas/class-control-mapper.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/schemas/class-schema-generator.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/validators/class-element-validator.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/validators/class-settings-validator.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-query-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-page-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-layout-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-widget-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-template-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-global-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-composite-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/class-openverse-client.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-stock-image-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-analyzer-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-clone-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-bulk-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-prompt-abilities.php';

	// Phase 4: Premium Features
	require_once MINDCRAFTS_AI_DIR . 'includes/class-license-manager.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-woocommerce-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-seo-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-addon-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-responsive-abilities.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-marketplace-abilities.php';

	require_once MINDCRAFTS_AI_DIR . 'includes/abilities/class-ability-registrar.php';
	require_once MINDCRAFTS_AI_DIR . 'includes/class-plugin.php';

	// Boot the plugin.
	MindCrafts_AI_Plugin::instance();
}
add_action( 'plugins_loaded', 'mindcrafts_ai_init', 20 );
