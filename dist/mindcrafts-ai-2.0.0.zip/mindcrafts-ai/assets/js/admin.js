/**
 * MindCrafts AI admin settings scripts.
 *
 * @package MindCrafts_AI
 */

(function () {
	'use strict';

	function initToolsForm() {
		var form = document.getElementById( 'mindcrafts-ai-tools-form' );
		if ( ! form ) {
			return;
		}

		var enableAll = form.querySelector( '.mindcrafts-ai-enable-all' );
		var disableAll = form.querySelector( '.mindcrafts-ai-disable-all' );

		if ( enableAll ) {
			enableAll.addEventListener( 'click', function () {
				form.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( checkbox ) {
					checkbox.checked = true;
				} );
				updateCards( form );
			} );
		}

		if ( disableAll ) {
			disableAll.addEventListener( 'click', function () {
				form.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( checkbox ) {
					checkbox.checked = false;
				} );
				updateCards( form );
			} );
		}

		form.querySelectorAll( '.mindcrafts-ai-category' ).forEach( function ( category ) {
			var catEnableAll = category.querySelector( '.mindcrafts-ai-cat-enable-all' );
			var catDisableAll = category.querySelector( '.mindcrafts-ai-cat-disable-all' );

			if ( catEnableAll ) {
				catEnableAll.addEventListener( 'click', function () {
					category.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( checkbox ) {
						checkbox.checked = true;
					} );
					updateCards( form );
				} );
			}

			if ( catDisableAll ) {
				catDisableAll.addEventListener( 'click', function () {
					category.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( checkbox ) {
						checkbox.checked = false;
					} );
					updateCards( form );
				} );
			}
		} );

		form.addEventListener( 'change', function ( event ) {
			if ( event.target.type === 'checkbox' ) {
				updateCards( form );
				updateEnabledIds( form );
			}
		} );

		form.addEventListener( 'submit', function () {
			updateEnabledIds( form );
		} );
	}

	function updateCards( form ) {
		form.querySelectorAll( '.mindcrafts-ai-tool-card' ).forEach( function ( card ) {
			var checkbox = card.querySelector( 'input[type="checkbox"]' );
			card.classList.toggle( 'is-enabled', checkbox.checked );
			card.classList.toggle( 'is-disabled', ! checkbox.checked );
		} );
	}

	function updateEnabledIds( form ) {
		var target = document.getElementById( 'mindcrafts-ai-enabled-ids' );
		var enabledIds = [];

		if ( ! target ) {
			return;
		}

		form.querySelectorAll( 'input[type="checkbox"][data-tool-id]' ).forEach( function ( checkbox ) {
			if ( checkbox.checked ) {
				enabledIds.push( checkbox.getAttribute( 'data-tool-id' ) );
			}
		} );

		target.value = enabledIds.join( ',' );
	}

	function copyToClipboard( text ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( text );
		}

		return new Promise( function ( resolve ) {
			var textarea = document.createElement( 'textarea' );
			textarea.value = text;
			textarea.style.position = 'fixed';
			textarea.style.opacity = '0';
			document.body.appendChild( textarea );
			textarea.select();
			document.execCommand( 'copy' );
			document.body.removeChild( textarea );
			resolve();
		} );
	}

	function initCopyButtons() {
		document.querySelectorAll( '.mindcrafts-ai-copy-btn' ).forEach( function ( button ) {
			button.addEventListener( 'click', function () {
				var targetId = this.getAttribute( 'data-target' );
				var source = document.getElementById( targetId );
				if ( ! source ) {
					return;
				}

				var copiedText = ( typeof mindcraftsAiAdmin !== 'undefined' && mindcraftsAiAdmin.copied ) ? mindcraftsAiAdmin.copied : 'Copied!';

				copyToClipboard( source.value ).then( function () {
					var original = button.textContent;
					button.textContent = copiedText;
					setTimeout( function () {
						button.textContent = original;
					}, 2000 );
				} );
			} );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			initToolsForm();
			initCopyButtons();
		} );
	} else {
		initToolsForm();
		initCopyButtons();
	}
})();
