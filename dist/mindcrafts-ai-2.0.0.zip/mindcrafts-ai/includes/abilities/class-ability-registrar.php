<?php
/**
 * Registers all MindCrafts AI abilities with the WordPress Abilities API.
 *
 * @package MindCrafts_AI
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central registrar that coordinates registration of all ability groups.
 *
 * @since 1.0.0
 */
class MindCrafts_AI_Ability_Registrar {

	/**
	 * The data access layer.
	 *
	 * @var MindCrafts_AI_Data
	 */
	private $data;

	/**
	 * The element factory.
	 *
	 * @var MindCrafts_AI_Element_Factory
	 */
	private $factory;

	/**
	 * The schema generator.
	 *
	 * @var MindCrafts_AI_Schema_Generator
	 */
	private $schema_generator;

	/**
	 * The settings validator.
	 *
	 * @var MindCrafts_AI_Settings_Validator
	 */
	private $validator;

	/**
	 * All registered ability names.
	 *
	 * @var string[]
	 */
	private $ability_names = array();

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 *
	 * @param MindCrafts_AI_Data               $data             The data access layer.
	 * @param MindCrafts_AI_Element_Factory    $factory          The element factory.
	 * @param MindCrafts_AI_Schema_Generator   $schema_generator The schema generator.
	 * @param MindCrafts_AI_Settings_Validator $validator        The settings validator.
	 */
	public function __construct(
		MindCrafts_AI_Data $data,
		MindCrafts_AI_Element_Factory $factory,
		MindCrafts_AI_Schema_Generator $schema_generator,
		MindCrafts_AI_Settings_Validator $validator
	) {
		$this->data             = $data;
		$this->factory          = $factory;
		$this->schema_generator = $schema_generator;
		$this->validator        = $validator;
	}

	/**
	 * Registers all abilities across all phases.
	 *
	 * Must be called during the `wp_abilities_api_init` action.
	 *
	 * @since 1.0.0
	 *
	 * @return string[] Array of registered ability names.
	 */
	public function register_all(): array {
		if ( ! empty( $this->ability_names ) ) {
			return $this->ability_names;
		}

		// Phase 1: Query/discovery abilities (P0 — read-only).
		$query = new MindCrafts_AI_Query_Abilities( $this->data, $this->schema_generator );
		$query->register();
		$this->ability_names = array_merge( $this->ability_names, $query->get_ability_names() );

		// Phase 2: Page CRUD abilities (P1).
		$pages = new MindCrafts_AI_Page_Abilities( $this->data, $this->factory );
		$pages->register();
		$this->ability_names = array_merge( $this->ability_names, $pages->get_ability_names() );

		// Phase 2: Layout/container abilities (P1).
		$layout = new MindCrafts_AI_Layout_Abilities( $this->data, $this->factory );
		$layout->register();
		$this->ability_names = array_merge( $this->ability_names, $layout->get_ability_names() );

		// Phase 3: Widget abilities — universal + convenience (P1/P2).
		$widgets = new MindCrafts_AI_Widget_Abilities( $this->data, $this->factory, $this->schema_generator, $this->validator );
		$widgets->register();
		$this->ability_names = array_merge( $this->ability_names, $widgets->get_ability_names() );

		// Phase 4: Template abilities (P2).
		$templates = new MindCrafts_AI_Template_Abilities( $this->data, $this->factory );
		$templates->register();
		$this->ability_names = array_merge( $this->ability_names, $templates->get_ability_names() );

		// Phase 4: Global settings abilities (P2).
		$globals = new MindCrafts_AI_Global_Abilities( $this->data );
		$globals->register();
		$this->ability_names = array_merge( $this->ability_names, $globals->get_ability_names() );

		// Phase 5: Composite abilities (P2).
		$composite = new MindCrafts_AI_Composite_Abilities( $this->data, $this->factory );
		$composite->register();
		$this->ability_names = array_merge( $this->ability_names, $composite->get_ability_names() );

		// Stock image abilities (search, sideload, add).
		$stock_images = new MindCrafts_AI_Stock_Image_Abilities( $this->data, $this->factory );
		$stock_images->register();
		$this->ability_names = array_merge( $this->ability_names, $stock_images->get_ability_names() );

		// Phase 3: Free AI Features.
		$analyzer = new MindCrafts_AI_Analyzer_Abilities( $this->data );
		$analyzer->register();
		$this->ability_names = array_merge( $this->ability_names, $analyzer->get_ability_names() );

		$clone = new MindCrafts_AI_Clone_Abilities( $this->data );
		$clone->register();
		$this->ability_names = array_merge( $this->ability_names, $clone->get_ability_names() );

		$bulk = new MindCrafts_AI_Bulk_Abilities( $this->data, $this->factory );
		$bulk->register();
		$this->ability_names = array_merge( $this->ability_names, $bulk->get_ability_names() );

		// T1-4 FIX: WooCommerce, Addon, and Responsive are now fully implemented.
		$woocommerce = new MindCrafts_AI_WooCommerce_Abilities( $this->data );
		$woocommerce->register();
		$this->ability_names = array_merge( $this->ability_names, $woocommerce->get_ability_names() );

		$addon = new MindCrafts_AI_Addon_Abilities( $this->data );
		$addon->register();
		$this->ability_names = array_merge( $this->ability_names, $addon->get_ability_names() );

		$responsive = new MindCrafts_AI_Responsive_Abilities( $this->data );
		$responsive->register();
		$this->ability_names = array_merge( $this->ability_names, $responsive->get_ability_names() );

		// SEO and Marketplace remain as stubs for now.
		new MindCrafts_AI_SEO_Abilities( $this->data );
		new MindCrafts_AI_Marketplace_Abilities( $this->data );

		/**
		 * Filters the registered ability names.
		 *
		 * Allows other plugins to add or modify ability names.
		 *
		 * @since 1.0.0
		 *
		 * @param string[] $ability_names The registered ability names.
		 */
		$this->ability_names = apply_filters( 'mindcrafts_ai_ability_names', $this->ability_names );

		return $this->ability_names;
	}

	/**
	 * Gets the list of registered ability names.
	 *
	 * @since 1.0.0
	 *
	 * @return string[] Array of ability names.
	 */
	public function get_ability_names(): array {
		return $this->ability_names;
	}
}
