<?php
/**
 * SEO abilities for MindCrafts AI.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_SEO_Abilities {

	private $data;
	private $license;

	public function __construct( $data ) {
		$this->data = $data;
		$this->license = MindCrafts_AI_License_Manager::instance();
	}

	public function get_ability_names(): array {
		return array(
			'mindcrafts-ai/optimize-seo',
		);
	}

	public function register(): void {
		wp_register_ability(
			'mindcrafts-ai/optimize-seo',
			array(
				'label'               => __( 'Optimize SEO', 'mindcrafts-ai' ),
				'description'         => __( 'AI-driven generation of meta tags, alt texts, and structure optimizations.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_optimize_seo' ),
				'permission_callback' => array( $this->license, 'check_premium_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array( 'type' => 'integer' ),
					),
					'required'   => array( 'post_id' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array( 'success' => array( 'type' => 'boolean' ) ),
				),
			)
		);
	}

	public function execute_optimize_seo( $input ) {
		return new \WP_Error(
			'premium_addon_required',
			__( 'SEO optimization tools require the production premium add-on. This placeholder does not modify SEO data.', 'mindcrafts-ai' )
		);
	}
}
