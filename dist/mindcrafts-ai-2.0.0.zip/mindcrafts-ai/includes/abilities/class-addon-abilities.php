<?php
/**
 * Addon abilities for MindCrafts AI.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_Addon_Abilities {

	private $data;
	private $factory;

	public function __construct( $data, $factory = null ) {
		$this->data = $data;
		$this->factory = $factory ? $factory : new MindCrafts_AI_Element_Factory();
	}

	public function get_ability_names(): array {
		return array(
			'mindcrafts-ai/list-addon-widgets',
			'mindcrafts-ai/add-third-party-widget',
		);
	}

	public function register(): void {
		wp_register_ability(
			'mindcrafts-ai/list-addon-widgets',
			array(
				'label'               => __( 'List Addon Widgets', 'mindcrafts-ai' ),
				'description'         => __( 'Lists all active third-party addon widgets (ElementsKit, Essential Addons, UAE, etc.) registered in Elementor.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_list_addon_widgets' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'addon_widgets' => array(
							'type' => 'array',
							'items' => array(
								'type' => 'object',
								'properties' => array(
									'name' => array( 'type' => 'string' ),
									'title' => array( 'type' => 'string' ),
									'categories' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
									'icon' => array( 'type' => 'string' ),
								),
							),
						),
					),
				),
			)
		);

		wp_register_ability(
			'mindcrafts-ai/add-third-party-widget',
			array(
				'label'               => __( 'Add 3rd-Party Widget', 'mindcrafts-ai' ),
				'description'         => __( 'Adds a third-party addon widget (ElementsKit, Essential Addons, UAE, etc.) to an Elementor container.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_add_third_party_widget' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'     => array( 'type' => 'integer', 'description' => __( 'The post/page ID.', 'mindcrafts-ai' ) ),
						'parent_id'   => array( 'type' => 'string', 'description' => __( 'Parent container ID.', 'mindcrafts-ai' ) ),
						'position'    => array( 'type' => 'integer', 'description' => __( 'Insert position. -1 = append.', 'mindcrafts-ai' ) ),
						'widget_type' => array( 'type' => 'string', 'description' => __( 'The addon widget type name (e.g. ekit-heading, eael-creative-button).', 'mindcrafts-ai' ) ),
						'settings'    => array( 'type' => 'object', 'description' => __( 'Widget-specific settings.', 'mindcrafts-ai' ) ),
					),
					'required'   => array( 'post_id', 'parent_id', 'widget_type' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'    => array( 'type' => 'boolean' ),
						'element_id' => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function check_permission( $input = null ): bool {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		$post_id = absint( $input['post_id'] ?? 0 );
		if ( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}
		return true;
	}

	public function execute_list_addon_widgets( $input = null ) {
		$widgets = \Elementor\Plugin::$instance->widgets_manager->get_widget_types();
		$addon_widgets = array();

		$core_categories = array( 'basic', 'pro', 'general', 'theme-elements', 'woocommerce', 'wordpress' );

		foreach ( $widgets as $name => $widget ) {
			$categories = $widget->get_categories();
			$is_core = false;
			foreach ( $categories as $cat ) {
				if ( in_array( $cat, $core_categories, true ) ) {
					$is_core = true;
					break;
				}
			}
			
			$name_lower = strtolower( $name );
			$is_addon = ! $is_core || 
				strpos( $name_lower, 'ekit-' ) === 0 || 
				strpos( $name_lower, 'eael-' ) === 0 || 
				strpos( $name_lower, 'uael-' ) === 0 ||
				strpos( $name_lower, 'premium-' ) === 0;

			if ( $is_addon ) {
				$addon_widgets[] = array(
					'name'       => $widget->get_name(),
					'title'      => $widget->get_title(),
					'categories' => $categories,
					'icon'       => $widget->get_icon(),
				);
			}
		}

		return array( 'addon_widgets' => $addon_widgets );
	}

	public function execute_add_third_party_widget( $input ) {
		$post_id     = absint( $input['post_id'] ?? 0 );
		$parent_id   = sanitize_text_field( $input['parent_id'] ?? '' );
		$position    = intval( $input['position'] ?? -1 );
		$widget_type = sanitize_text_field( $input['widget_type'] ?? '' );
		$settings    = $input['settings'] ?? array();

		if ( ! $post_id || empty( $parent_id ) || empty( $widget_type ) ) {
			return new \WP_Error( 'missing_params', __( 'post_id, parent_id, and widget_type are required.', 'mindcrafts-ai' ) );
		}

		$widget_instance = \Elementor\Plugin::$instance->widgets_manager->get_widget_types( $widget_type );
		if ( ! $widget_instance ) {
			return new \WP_Error(
				'invalid_widget_type',
				sprintf( __( 'Widget type "%s" not found. Please ensure the addon plugin is active.', 'mindcrafts-ai' ), $widget_type )
			);
		}

		$page_data = $this->data->get_page_data( $post_id );
		if ( is_wp_error( $page_data ) ) {
			return $page_data;
		}

		$widget = $this->factory->create_widget( $widget_type, $settings );
		$inserted = $this->data->insert_element( $page_data, $parent_id, $widget, $position );
		if ( ! $inserted ) {
			return new \WP_Error( 'parent_not_found', __( 'Parent container not found.', 'mindcrafts-ai' ) );
		}

		$result = $this->data->save_page_data( $post_id, $page_data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success'    => true,
			'element_id' => $widget['id'],
		);
	}
}
