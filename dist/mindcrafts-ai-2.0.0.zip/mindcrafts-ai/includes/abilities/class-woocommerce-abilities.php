<?php
/**
 * WooCommerce abilities for MindCrafts AI.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_WooCommerce_Abilities {

	private $data;
	private $factory;

	public function __construct( $data, $factory = null ) {
		$this->data = $data;
		$this->factory = $factory ? $factory : new MindCrafts_AI_Element_Factory();
	}

	public function get_ability_names(): array {
		return array(
			'mindcrafts-ai/add-woocommerce-products',
			'mindcrafts-ai/add-woocommerce-categories',
		);
	}

	public function register(): void {
		wp_register_ability(
			'mindcrafts-ai/add-woocommerce-products',
			array(
				'label'               => __( 'Add WooCommerce Products Grid', 'mindcrafts-ai' ),
				'description'         => __( 'Adds a WooCommerce products grid widget to an Elementor container.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_add_products' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'   => array( 'type' => 'integer', 'description' => __( 'The post/page ID.', 'mindcrafts-ai' ) ),
						'parent_id' => array( 'type' => 'string', 'description' => __( 'Parent container element ID.', 'mindcrafts-ai' ) ),
						'position'  => array( 'type' => 'integer', 'description' => __( 'Insert position. -1 = append.', 'mindcrafts-ai' ) ),
						'columns'   => array( 'type' => 'integer', 'description' => __( 'Number of columns to show.', 'mindcrafts-ai' ) ),
						'rows'      => array( 'type' => 'integer', 'description' => __( 'Number of rows to show.', 'mindcrafts-ai' ) ),
						'orderby'   => array( 'type' => 'string', 'description' => __( 'Order products by.', 'mindcrafts-ai' ) ),
						'order'     => array( 'type' => 'string', 'enum' => array( 'ASC', 'DESC' ), 'description' => __( 'Sort order.', 'mindcrafts-ai' ) ),
					),
					'required'   => array( 'post_id', 'parent_id' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'    => array( 'type' => 'boolean' ),
						'element_id' => array( 'type' => 'string' ),
					),
				),
			)
		);

		wp_register_ability(
			'mindcrafts-ai/add-woocommerce-categories',
			array(
				'label'               => __( 'Add WooCommerce Categories Grid', 'mindcrafts-ai' ),
				'description'         => __( 'Adds a WooCommerce product categories grid widget to an Elementor container.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_add_categories' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'   => array( 'type' => 'integer', 'description' => __( 'The post/page ID.', 'mindcrafts-ai' ) ),
						'parent_id' => array( 'type' => 'string', 'description' => __( 'Parent container element ID.', 'mindcrafts-ai' ) ),
						'position'  => array( 'type' => 'integer', 'description' => __( 'Insert position. -1 = append.', 'mindcrafts-ai' ) ),
						'columns'   => array( 'type' => 'integer', 'description' => __( 'Number of columns to show.', 'mindcrafts-ai' ) ),
						'number'    => array( 'type' => 'integer', 'description' => __( 'Total number of categories to show.', 'mindcrafts-ai' ) ),
					),
					'required'   => array( 'post_id', 'parent_id' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'    => array( 'type' => 'boolean' ),
						'element_id' => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function check_permission( $input = null ): bool {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		$post_id = absint( $input['post_id'] ?? 0 );
		if ( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}
		return true;
	}

	public function execute_add_products( $input ) {
		$post_id     = absint( $input['post_id'] ?? 0 );
		$parent_id   = sanitize_text_field( $input['parent_id'] ?? '' );
		$position    = intval( $input['position'] ?? -1 );
		$columns     = absint( $input['columns'] ?? 4 );
		$rows        = absint( $input['rows'] ?? 1 );
		$orderby     = sanitize_text_field( $input['orderby'] ?? 'date' );
		$order       = sanitize_text_field( $input['order'] ?? 'DESC' );

		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'woocommerce_not_active', __( 'WooCommerce must be active to use this tool.', 'mindcrafts-ai' ) );
		}

		$settings = array(
			'columns' => $columns,
			'rows' => $rows,
			'orderby' => $orderby,
			'order' => $order,
		);

		$page_data = $this->data->get_page_data( $post_id );
		if ( is_wp_error( $page_data ) ) {
			return $page_data;
		}

		$widget_type = 'woocommerce-products';
		$widget = $this->factory->create_widget( $widget_type, $settings );
		$inserted = $this->data->insert_element( $page_data, $parent_id, $widget, $position );
		if ( ! $inserted ) {
			return new \WP_Error( 'parent_not_found', __( 'Parent container not found.', 'mindcrafts-ai' ) );
		}

		$result = $this->data->save_page_data( $post_id, $page_data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success' => true,
			'element_id' => $widget['id'],
		);
	}

	public function execute_add_categories( $input ) {
		$post_id     = absint( $input['post_id'] ?? 0 );
		$parent_id   = sanitize_text_field( $input['parent_id'] ?? '' );
		$position    = intval( $input['position'] ?? -1 );
		$columns     = absint( $input['columns'] ?? 4 );
		$number      = absint( $input['number'] ?? 4 );

		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'woocommerce_not_active', __( 'WooCommerce must be active to use this tool.', 'mindcrafts-ai' ) );
		}

		$settings = array(
			'columns' => $columns,
			'number' => $number,
		);

		$page_data = $this->data->get_page_data( $post_id );
		if ( is_wp_error( $page_data ) ) {
			return $page_data;
		}

		$widget_type = 'woocommerce-categories';
		$widget = $this->factory->create_widget( $widget_type, $settings );
		$inserted = $this->data->insert_element( $page_data, $parent_id, $widget, $position );
		if ( ! $inserted ) {
			return new \WP_Error( 'parent_not_found', __( 'Parent container not found.', 'mindcrafts-ai' ) );
		}

		$result = $this->data->save_page_data( $post_id, $page_data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success' => true,
			'element_id' => $widget['id'],
		);
	}
}
