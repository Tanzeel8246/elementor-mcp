<?php
/**
 * Responsive abilities for MindCrafts AI.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_Responsive_Abilities {

	private $data;

	public function __construct( $data ) {
		$this->data = $data;
	}

	public function get_ability_names(): array {
		return array(
			'mindcrafts-ai/update-responsive-settings',
		);
	}

	public function register(): void {
		wp_register_ability(
			'mindcrafts-ai/update-responsive-settings',
			array(
				'label'               => __( 'Update Responsive Settings', 'mindcrafts-ai' ),
				'description'         => __( 'Adjusts element settings specifically for mobile or tablet views by automatically suffixing keys with the breakpoint suffix.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_update_responsive' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'    => array( 'type' => 'integer', 'description' => __( 'The post/page ID.', 'mindcrafts-ai' ) ),
						'element_id' => array( 'type' => 'string', 'description' => __( 'The element ID.', 'mindcrafts-ai' ) ),
						'breakpoint' => array( 'type' => 'string', 'enum' => array( 'mobile', 'tablet' ), 'description' => __( 'The breakpoint view to target.', 'mindcrafts-ai' ) ),
						'settings'   => array( 'type' => 'object', 'description' => __( 'Settings object to set for the breakpoint.', 'mindcrafts-ai' ) ),
					),
					'required'   => array( 'post_id', 'element_id', 'breakpoint', 'settings' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'    => array( 'type' => 'boolean' ),
						'element_id' => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function check_permission( $input = null ): bool {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		$post_id = absint( $input['post_id'] ?? 0 );
		if ( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}
		return true;
	}

	public function execute_update_responsive( $input ) {
		$post_id    = absint( $input['post_id'] ?? 0 );
		$element_id = sanitize_text_field( $input['element_id'] ?? '' );
		$breakpoint = sanitize_text_field( $input['breakpoint'] ?? '' );
		$settings   = $input['settings'] ?? array();

		if ( ! $post_id || empty( $element_id ) || empty( $breakpoint ) || empty( $settings ) ) {
			return new \WP_Error( 'missing_params', __( 'post_id, element_id, breakpoint, and settings are required.', 'mindcrafts-ai' ) );
		}

		if ( ! in_array( $breakpoint, array( 'mobile', 'tablet' ), true ) ) {
			return new \WP_Error( 'invalid_breakpoint', __( 'Breakpoint must be "mobile" or "tablet".', 'mindcrafts-ai' ) );
		}

		$page_data = $this->data->get_page_data( $post_id );
		if ( is_wp_error( $page_data ) ) {
			return $page_data;
		}

		$responsive_settings = array();
		$suffix = '_' . $breakpoint;

		foreach ( $settings as $key => $value ) {
			if ( substr( $key, -strlen( $suffix ) ) === $suffix ) {
				$responsive_settings[ $key ] = $value;
			} else {
				$responsive_settings[ $key . $suffix ] = $value;
			}
		}

		$updated = $this->data->update_element_settings( $page_data, $element_id, $responsive_settings );

		if ( ! $updated ) {
			return new \WP_Error( 'element_not_found', __( 'Element not found or failed to update.', 'mindcrafts-ai' ) );
		}

		$result = $this->data->save_page_data( $post_id, $page_data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success'    => true,
			'element_id' => $element_id,
		);
	}
}
