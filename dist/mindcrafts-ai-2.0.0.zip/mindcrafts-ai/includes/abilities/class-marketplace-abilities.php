<?php
/**
 * Marketplace abilities for MindCrafts AI.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_Marketplace_Abilities {

	private $data;
	private $license;

	public function __construct( $data ) {
		$this->data = $data;
		$this->license = MindCrafts_AI_License_Manager::instance();
	}

	public function get_ability_names(): array {
		return array(
			'mindcrafts-ai/import-premium-template',
		);
	}

	public function register(): void {
		wp_register_ability(
			'mindcrafts-ai/import-premium-template',
			array(
				'label'               => __( 'Import Premium Template', 'mindcrafts-ai' ),
				'description'         => __( 'Downloads and imports a premium template from the MindCrafts AI marketplace.', 'mindcrafts-ai' ),
				'category'            => 'mindcrafts-ai',
				'execute_callback'    => array( $this, 'execute_import_premium' ),
				'permission_callback' => array( $this->license, 'check_premium_permission' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'     => array( 'type' => 'integer' ),
						'template_id' => array( 'type' => 'string' ),
					),
					'required'   => array( 'post_id', 'template_id' ),
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array( 'success' => array( 'type' => 'boolean' ) ),
				),
			)
		);
	}

	public function execute_import_premium( $input ) {
		return new \WP_Error(
			'premium_addon_required',
			__( 'Template marketplace import requires the production premium add-on. This placeholder does not import templates.', 'mindcrafts-ai' )
		);
	}
}
