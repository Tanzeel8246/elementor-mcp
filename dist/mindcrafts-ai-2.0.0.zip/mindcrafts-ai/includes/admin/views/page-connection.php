<?php
/**
 * Status tab view for the MindCrafts AI admin settings page.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var MindCrafts_AI_Admin $this */
$enabled_count   = $this->get_enabled_tool_count();
$total_count     = $this->get_total_tool_count();
$has_elementor   = did_action( 'elementor/loaded' );
$has_mcp_adapter = class_exists( '\WP\MCP\Core\McpAdapter' );
$has_abilities   = function_exists( 'wp_register_ability' );
$mcp_endpoint    = rest_url( 'mcp/mindcrafts-ai-server' );
?>

<div class="mindcrafts-ai-connection">
	<div class="mindcrafts-ai-section">
		<h2><?php esc_html_e( 'Connection Status', 'mindcrafts-ai' ); ?></h2>
		<table class="form-table mindcrafts-ai-status-table">
			<tr>
				<th><?php esc_html_e( 'MindCrafts AI', 'mindcrafts-ai' ); ?></th>
				<td><span class="mindcrafts-ai-status mindcrafts-ai-status--active"><?php esc_html_e( 'Active', 'mindcrafts-ai' ); ?></span></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Elementor', 'mindcrafts-ai' ); ?></th>
				<td>
					<?php if ( $has_elementor ) : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--active"><?php esc_html_e( 'Active', 'mindcrafts-ai' ); ?></span>
					<?php else : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--inactive"><?php esc_html_e( 'Missing', 'mindcrafts-ai' ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'MCP Adapter', 'mindcrafts-ai' ); ?></th>
				<td>
					<?php if ( $has_mcp_adapter ) : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--active"><?php esc_html_e( 'Active', 'mindcrafts-ai' ); ?></span>
					<?php else : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--inactive"><?php esc_html_e( 'Missing', 'mindcrafts-ai' ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Abilities API', 'mindcrafts-ai' ); ?></th>
				<td>
					<?php if ( $has_abilities ) : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--active"><?php esc_html_e( 'Available', 'mindcrafts-ai' ); ?></span>
					<?php else : ?>
						<span class="mindcrafts-ai-status mindcrafts-ai-status--inactive"><?php esc_html_e( 'Missing', 'mindcrafts-ai' ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Enabled Tools', 'mindcrafts-ai' ); ?></th>
				<td>
					<?php
					printf(
						/* translators: %1$d: enabled count, %2$d: total count */
						esc_html__( '%1$d of %2$d', 'mindcrafts-ai' ),
						$enabled_count,
						$total_count
					);
					?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Connection Endpoint', 'mindcrafts-ai' ); ?></th>
				<td><code><?php echo esc_html( $mcp_endpoint ); ?></code></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Server Name', 'mindcrafts-ai' ); ?></th>
				<td><code><?php echo esc_html( 'mindcrafts-ai-server' ); ?></code></td>
			</tr>
		</table>
	</div>

	<div class="mindcrafts-ai-section">
		<h2><?php esc_html_e( 'How to Test', 'mindcrafts-ai' ); ?></h2>
		<p>
			<?php esc_html_e( 'Keep Elementor, the MCP Adapter, and the Abilities API active. Your AI client should connect to the endpoint and server name shown above.', 'mindcrafts-ai' ); ?>
		</p>
		<p>
			<?php esc_html_e( 'A quick first check is to confirm that the tool count is greater than zero and all required services show as active.', 'mindcrafts-ai' ); ?>
		</p>
	</div>
</div>
