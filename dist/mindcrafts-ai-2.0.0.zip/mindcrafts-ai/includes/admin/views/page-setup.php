<?php
/**
 * Setup tab view for the MindCrafts AI admin page.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var MindCrafts_AI_Admin $this */
$dependencies = $this->get_dependency_definitions();
$mcp_endpoint = rest_url( 'mcp/mindcrafts-ai-server' );
$server_name  = 'mindcrafts-ai-server';
$tool_count   = $this->get_total_tool_count();

$stdio_config = wp_json_encode(
	array(
		'mcpServers' => array(
			$server_name => array(
				'command' => 'npx.cmd',
				'args'    => array(
					'-y',
					'@automattic/mcp-wordpress-remote@latest',
				),
				'env'     => array(
					'WP_API_URL'      => $mcp_endpoint,
					'WP_API_USERNAME' => 'YOUR_WORDPRESS_USERNAME',
					'WP_API_PASSWORD' => 'YOUR_APPLICATION_PASSWORD_ONLY',
					'OAUTH_ENABLED'   => 'false',
				),
			),
		),
	),
	JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
);

if ( ! is_string( $stdio_config ) ) {
	$stdio_config = '';
}

$notice_messages = array(
	'installed'             => __( 'Dependency installed and activated.', 'mindcrafts-ai' ),
	'activated'             => __( 'Dependency activated.', 'mindcrafts-ai' ),
	'already_active'        => __( 'Dependency is already active.', 'mindcrafts-ai' ),
	'install_failed'        => __( 'Installation failed. Please install this dependency manually, then return to this setup screen.', 'mindcrafts-ai' ),
	'activate_failed'       => __( 'Activation failed. Please check the Plugins screen for the detailed WordPress error.', 'mindcrafts-ai' ),
	'install_not_supported' => __( 'Automatic installation is not available for this dependency.', 'mindcrafts-ai' ),
	'not_installed'         => __( 'This dependency is not installed yet.', 'mindcrafts-ai' ),
	'unknown_dependency'    => __( 'Unknown dependency.', 'mindcrafts-ai' ),
);

$notice_result = isset( $_GET['dependency_result'] ) ? sanitize_key( wp_unslash( $_GET['dependency_result'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>

<?php if ( $notice_result && isset( $notice_messages[ $notice_result ] ) ) : ?>
	<div class="notice <?php echo esc_attr( in_array( $notice_result, array( 'install_failed', 'activate_failed', 'install_not_supported', 'not_installed', 'unknown_dependency' ), true ) ? 'notice-error' : 'notice-success' ); ?> is-dismissible">
		<p><?php echo esc_html( $notice_messages[ $notice_result ] ); ?></p>
	</div>
<?php endif; ?>

<div class="mindcrafts-ai-setup">
	<div class="mindcrafts-ai-section">
		<h2><?php esc_html_e( 'Required Setup', 'mindcrafts-ai' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Install and activate the required WordPress pieces from here. After everything is active, your AI client can connect to the MindCrafts AI MCP server.', 'mindcrafts-ai' ); ?>
		</p>

		<div class="mindcrafts-ai-dependency-grid">
			<?php foreach ( $dependencies as $dependency_key => $dependency ) : ?>
				<?php $status = $this->get_dependency_status( $dependency_key ); ?>
				<div class="mindcrafts-ai-dependency-card">
					<div class="mindcrafts-ai-dependency-header">
						<h3><?php echo esc_html( $dependency['label'] ); ?></h3>
						<?php if ( $status['is_active'] ) : ?>
							<span class="mindcrafts-ai-status mindcrafts-ai-status--active"><?php esc_html_e( 'Active', 'mindcrafts-ai' ); ?></span>
						<?php elseif ( $status['is_installed'] ) : ?>
							<span class="mindcrafts-ai-status mindcrafts-ai-status--warning"><?php esc_html_e( 'Installed', 'mindcrafts-ai' ); ?></span>
						<?php else : ?>
							<span class="mindcrafts-ai-status mindcrafts-ai-status--inactive"><?php esc_html_e( 'Missing', 'mindcrafts-ai' ); ?></span>
						<?php endif; ?>
					</div>

					<p><?php echo esc_html( $dependency['description'] ); ?></p>

					<ul class="mindcrafts-ai-dependency-meta">
						<li>
							<strong><?php esc_html_e( 'Source', 'mindcrafts-ai' ); ?>:</strong>
							<?php echo esc_html( $dependency['source_label'] ); ?>
						</li>
						<li>
							<strong><?php esc_html_e( 'Plugin file', 'mindcrafts-ai' ); ?>:</strong>
							<?php if ( $status['plugin_file'] ) : ?>
								<code><?php echo esc_html( $status['plugin_file'] ); ?></code>
							<?php elseif ( $status['is_active'] ) : ?>
								<?php esc_html_e( 'Loaded by WordPress', 'mindcrafts-ai' ); ?>
							<?php else : ?>
								<?php esc_html_e( 'Not found yet', 'mindcrafts-ai' ); ?>
							<?php endif; ?>
						</li>
					</ul>

					<div class="mindcrafts-ai-dependency-action">
						<?php if ( $status['is_active'] ) : ?>
							<span class="mindcrafts-ai-ready-mark"><?php esc_html_e( 'Ready', 'mindcrafts-ai' ); ?></span>
						<?php elseif ( $status['is_installed'] && current_user_can( 'activate_plugins' ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="mindcrafts_ai_activate_dependency" />
								<input type="hidden" name="dependency" value="<?php echo esc_attr( $dependency_key ); ?>" />
								<?php wp_nonce_field( 'mindcrafts_ai_dependency_' . $dependency_key, 'mindcrafts_ai_nonce' ); ?>
								<?php submit_button( __( 'Activate', 'mindcrafts-ai' ), 'primary', 'submit', false ); ?>
							</form>
						<?php elseif ( ! empty( $dependency['installable'] ) && current_user_can( 'install_plugins' ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="mindcrafts_ai_install_dependency" />
								<input type="hidden" name="dependency" value="<?php echo esc_attr( $dependency_key ); ?>" />
								<?php wp_nonce_field( 'mindcrafts_ai_dependency_' . $dependency_key, 'mindcrafts_ai_nonce' ); ?>
								<?php submit_button( __( 'Install & Activate', 'mindcrafts-ai' ), 'primary', 'submit', false ); ?>
							</form>
						<?php else : ?>
							<p class="description"><?php echo esc_html( $dependency['manual_message'] ); ?></p>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>

	<div class="mindcrafts-ai-section">
		<h2><?php esc_html_e( 'AI Connection Preset', 'mindcrafts-ai' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Use this STDIO preset for Codex, Claude Desktop, Cursor, Windsurf, and most MCP clients. It avoids direct HTTP handshake/session issues and connects through the official WordPress remote MCP bridge.', 'mindcrafts-ai' ); ?>
		</p>

		<div class="mindcrafts-ai-connection-grid">
			<div class="mindcrafts-ai-connection-card">
				<h3><?php esc_html_e( 'Recommended: STDIO Proxy', 'mindcrafts-ai' ); ?></h3>
				<table class="form-table mindcrafts-ai-status-table">
					<tr>
						<th><?php esc_html_e( 'Server Name', 'mindcrafts-ai' ); ?></th>
						<td><code><?php echo esc_html( $server_name ); ?></code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Command', 'mindcrafts-ai' ); ?></th>
						<td><code>npx.cmd</code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Arguments', 'mindcrafts-ai' ); ?></th>
						<td><code>-y @automattic/mcp-wordpress-remote@latest</code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Endpoint', 'mindcrafts-ai' ); ?></th>
						<td><code><?php echo esc_html( $mcp_endpoint ); ?></code></td>
					</tr>
				</table>
				<textarea class="mindcrafts-ai-config-textarea" rows="14" readonly><?php echo esc_textarea( $stdio_config ); ?></textarea>
			</div>

			<div class="mindcrafts-ai-connection-card">
				<h3><?php esc_html_e( 'Direct HTTP Fallback', 'mindcrafts-ai' ); ?></h3>
				<table class="form-table mindcrafts-ai-status-table">
					<tr>
						<th><?php esc_html_e( 'Type', 'mindcrafts-ai' ); ?></th>
						<td><code>Streamable HTTP</code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'URL', 'mindcrafts-ai' ); ?></th>
						<td><code><?php echo esc_html( $mcp_endpoint ); ?></code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Header', 'mindcrafts-ai' ); ?></th>
						<td><code>Authorization: Basic BASE64(username:application-password)</code></td>
					</tr>
				</table>
				<p class="description">
					<?php esc_html_e( 'Use direct HTTP only when the AI client fully supports Streamable HTTP sessions. For Codex Desktop, the STDIO proxy preset is the safer default.', 'mindcrafts-ai' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mindcrafts-ai-section">
		<h2><?php esc_html_e( 'Connection Checklist', 'mindcrafts-ai' ); ?></h2>
		<ul class="mindcrafts-ai-checklist">
			<li><?php esc_html_e( 'All required dependencies should show Active above.', 'mindcrafts-ai' ); ?></li>
			<li>
				<?php
				printf(
					/* translators: %d: total number of registered MindCrafts AI tools */
					esc_html__( 'MindCrafts AI should expose %d tools when all tool toggles are enabled.', 'mindcrafts-ai' ),
					$tool_count
				);
				?>
			</li>
			<li><?php esc_html_e( 'Create a fresh WordPress Application Password for your AI client, and do not reuse a password that was shared publicly.', 'mindcrafts-ai' ); ?></li>
			<li><?php esc_html_e( 'After saving the MCP client config, restart the AI client and run a read-only test such as list pages or list widgets.', 'mindcrafts-ai' ); ?></li>
		</ul>
	</div>
</div>
