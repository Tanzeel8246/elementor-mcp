<?php
/**
 * Tools tab view for the MindCrafts AI admin settings page.
 *
 * Displays all MCP tools grouped by category with toggle checkboxes.
 *
 * @package MindCrafts_AI
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var MindCrafts_AI_Admin $this */
$all_tools     = $this->get_all_tools();
$disabled      = get_option( MindCrafts_AI_Admin::OPTION_DISABLED_TOOLS, array() );
$enabled_count = $this->get_enabled_tool_count();
$total_count   = $this->get_total_tool_count();
$tool_ids      = array_flip( $this->get_all_tool_slugs() );
$enabled_ids   = array();

foreach ( $tool_ids as $slug => $tool_id ) {
	if ( ! in_array( $slug, $disabled, true ) ) {
		$enabled_ids[] = $tool_id;
	}
}
?>

<?php if ( isset( $_GET['settings-updated'] ) && 'true' === sanitize_key( wp_unslash( $_GET['settings-updated'] ) ) ) : ?>
	<div class="notice notice-success is-dismissible">
		<p><?php esc_html_e( 'MindCrafts AI settings saved.', 'mindcrafts-ai' ); ?></p>
	</div>
<?php endif; ?>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="mindcrafts-ai-tools-form">
	<?php wp_nonce_field( 'mindcrafts_ai_save_tools', 'mindcrafts_ai_nonce' ); ?>
	<input type="hidden" name="action" value="mindcrafts_ai_save_tools" />
	<input type="hidden" name="mindcrafts_ai_enabled_ids" id="mindcrafts-ai-enabled-ids" value="<?php echo esc_attr( implode( ',', $enabled_ids ) ); ?>" />

	<p class="description">
		<?php
		printf(
			/* translators: %1$d: enabled count, %2$d: total count */
			esc_html__( '%1$d of %2$d tools enabled.', 'mindcrafts-ai' ),
			$enabled_count,
			$total_count
		);
		?>
	</p>

	<div class="mindcrafts-ai-bulk-actions">
		<button type="button" class="button mindcrafts-ai-enable-all"><?php esc_html_e( 'Enable All', 'mindcrafts-ai' ); ?></button>
		<button type="button" class="button mindcrafts-ai-disable-all"><?php esc_html_e( 'Disable All', 'mindcrafts-ai' ); ?></button>
	</div>

	<?php foreach ( $all_tools as $category_id => $category ) : ?>
		<div class="mindcrafts-ai-category" data-category="<?php echo esc_attr( $category_id ); ?>">
			<h2 class="mindcrafts-ai-category-header">
				<?php echo esc_html( $category['label'] ); ?>
				<span class="mindcrafts-ai-category-count">
					<?php
					$cat_total   = count( $category['tools'] );
					$cat_enabled = 0;
					foreach ( $category['tools'] as $slug => $tool ) {
						if ( ! in_array( $slug, $disabled, true ) ) {
							$cat_enabled++;
						}
					}
					printf(
						/* translators: %1$d: enabled, %2$d: total */
						esc_html__( '(%1$d/%2$d)', 'mindcrafts-ai' ),
						$cat_enabled,
						$cat_total
					);
					?>
				</span>
				<span class="mindcrafts-ai-category-actions">
					<button type="button" class="button-link mindcrafts-ai-cat-enable-all"><?php esc_html_e( 'All', 'mindcrafts-ai' ); ?></button>
					<span class="mindcrafts-ai-separator">|</span>
					<button type="button" class="button-link mindcrafts-ai-cat-disable-all"><?php esc_html_e( 'None', 'mindcrafts-ai' ); ?></button>
				</span>
			</h2>

			<div class="mindcrafts-ai-tools-grid">
				<?php foreach ( $category['tools'] as $slug => $tool ) : ?>
					<?php $is_enabled = ! in_array( $slug, $disabled, true ); ?>
					<label class="mindcrafts-ai-tool-card <?php echo esc_attr( $is_enabled ? 'is-enabled' : 'is-disabled' ); ?>">
						<input
							type="checkbox"
							data-tool-id="<?php echo esc_attr( $tool_ids[ $slug ] ); ?>"
							<?php checked( $is_enabled ); ?>
						/>
						<span class="mindcrafts-ai-tool-info">
							<span class="mindcrafts-ai-tool-name">
								<?php echo esc_html( $tool['label'] ); ?>
								<?php foreach ( $tool['badges'] as $badge ) : ?>
									<span class="mindcrafts-ai-badge mindcrafts-ai-badge--<?php echo esc_attr( $badge ); ?>">
										<?php echo esc_html( $badge ); ?>
									</span>
								<?php endforeach; ?>
							</span>
							<span class="mindcrafts-ai-tool-desc"><?php echo esc_html( $tool['description'] ); ?></span>
							<code class="mindcrafts-ai-tool-slug"><?php echo esc_html( $slug ); ?></code>
						</span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endforeach; ?>

	<?php submit_button( __( 'Save Changes', 'mindcrafts-ai' ) ); ?>
</form>
