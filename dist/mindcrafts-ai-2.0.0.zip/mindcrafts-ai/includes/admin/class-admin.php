<?php
/**
 * Admin settings page for MindCrafts AI.
 *
 * Provides a UI to toggle individual MCP tools on/off and view
 * connection information for various MCP clients.
 *
 * @package MindCrafts_AI
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page orchestrator.
 *
 * @since 1.0.0
 */
class MindCrafts_AI_Admin {

	/**
	 * The page hook suffix returned by add_options_page().
	 *
	 * @var string
	 */
	private $hook_suffix = '';

	/**
	 * Option name for storing disabled tools.
	 *
	 * @var string
	 */
	const OPTION_DISABLED_TOOLS = 'mindcrafts_ai_disabled_tools';

	/**
	 * Settings group name.
	 *
	 * @var string
	 */
	const SETTINGS_GROUP = 'mindcrafts_ai_settings';

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'mindcrafts-ai-dashboard';

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public function init(): void {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_mindcrafts_ai_save_tools', array( $this, 'handle_tools_save' ) );
		add_action( 'admin_post_mindcrafts_ai_install_dependency', array( $this, 'handle_dependency_install' ) );
		add_action( 'admin_post_mindcrafts_ai_activate_dependency', array( $this, 'handle_dependency_activate' ) );
		add_filter( 'mindcrafts_ai_ability_names', array( $this, 'filter_ability_names' ) );
		add_filter( 'plugin_action_links_' . MINDCRAFTS_AI_BASENAME, array( $this, 'add_plugin_action_links' ) );
	}

	/**
	 * Adds quick links to the Plugins screen.
	 *
	 * @since 2.0.0
	 *
	 * @param string[] $links Existing action links.
	 * @return string[] Action links with Settings first.
	 */
	public function add_plugin_action_links( array $links ): array {
		$settings_link = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&tab=setup' ) ),
			esc_html__( 'Setup', 'mindcrafts-ai' )
		);

		array_unshift( $links, $settings_link );

		return $links;
	}

	/**
	 * Add the settings page under the Settings menu.
	 *
	 * @since 1.0.0
	 */
	public function add_settings_page(): void {
		$this->hook_suffix = add_menu_page(
			__( 'MindCrafts AI', 'mindcrafts-ai' ),
			__( 'MindCrafts AI', 'mindcrafts-ai' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			'dashicons-admin-generic',
			58
		);
	}

	/**
	 * Register the settings with the WordPress Settings API.
	 *
	 * @since 1.0.0
	 */
	public function register_settings(): void {
		register_setting(
			self::SETTINGS_GROUP,
			self::OPTION_DISABLED_TOOLS,
			array(
				'type'              => 'array',
				'default'           => array(),
				'sanitize_callback' => array( $this, 'sanitize_disabled_tools' ),
			)
		);
	}

	/**
	 * Handles the tools form save without sending ability slugs in the request.
	 *
	 * Some managed hosts block POST payloads containing values like
	 * `delete`, `import`, or slash-delimited tool names. This handler accepts
	 * numeric tool IDs only, then maps them back to the canonical tool slugs.
	 *
	 * @since 2.0.0
	 */
	public function handle_tools_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage MindCrafts AI settings.', 'mindcrafts-ai' ) );
		}

		check_admin_referer( 'mindcrafts_ai_save_tools', 'mindcrafts_ai_nonce' );

		$all_tools   = $this->get_all_tool_slugs();
		$enabled_ids = array();

		if ( isset( $_POST['mindcrafts_ai_enabled_ids'] ) ) {
			$raw_enabled_ids = sanitize_text_field( wp_unslash( $_POST['mindcrafts_ai_enabled_ids'] ) );
			$enabled_ids     = '' === $raw_enabled_ids ? array() : array_map( 'absint', explode( ',', $raw_enabled_ids ) );
		} elseif ( isset( $_POST['mindcrafts_ai_enabled_tools'] ) && is_array( $_POST['mindcrafts_ai_enabled_tools'] ) ) {
			$raw_enabled_ids = wp_unslash( $_POST['mindcrafts_ai_enabled_tools'] );
			$enabled_ids     = array_map( 'absint', $raw_enabled_ids );
		}

		$enabled_tools = array();
		foreach ( array_unique( $enabled_ids ) as $tool_id ) {
			if ( isset( $all_tools[ $tool_id ] ) ) {
				$enabled_tools[] = $all_tools[ $tool_id ];
			}
		}

		$disabled_tools = array_values( array_diff( $all_tools, $enabled_tools ) );

		update_option( self::OPTION_DISABLED_TOOLS, $disabled_tools );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'             => self::PAGE_SLUG,
					'settings-updated' => 'true',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Sanitize the disabled tools option value.
	 *
	 * The form submits an array of enabled tool slugs. We compute the
	 * disabled list as the difference between all known tools and the
	 * enabled ones submitted.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $input The raw form input.
	 * @return string[] Sanitized array of disabled tool slugs.
	 */
	public function sanitize_disabled_tools( $input ): array {
		$enabled_tools = array();

		if ( is_array( $input ) ) {
			$enabled_tools = array_map( 'sanitize_text_field', $input );
		}

		// Get all known tool slugs.
		$all_tools = $this->get_all_tool_slugs();

		// Disabled = all tools minus the ones that were checked.
		$disabled = array_values( array_diff( $all_tools, $enabled_tools ) );

		return $disabled;
	}

	/**
	 * Enqueue admin CSS on our settings page only.
	 *
	 * @since 1.0.0
	 *
	 * @param string $hook The current admin page hook.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( $hook !== $this->hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mindcrafts-ai-admin',
			MINDCRAFTS_AI_URL . 'assets/css/admin.css',
			array(),
			MINDCRAFTS_AI_VERSION
		);

		wp_enqueue_script(
			'mindcrafts-ai-admin',
			MINDCRAFTS_AI_URL . 'assets/js/admin.js',
			array(),
			MINDCRAFTS_AI_VERSION,
			true
		);

		wp_localize_script(
			'mindcrafts-ai-admin',
			'mindcraftsAiAdmin',
			array(
				'copied' => __( 'Copied!', 'mindcrafts-ai' ),
			)
		);
	}

	/**
	 * Filter ability names to remove disabled tools.
	 *
	 * @since 1.0.0
	 *
	 * @param string[] $names The registered ability names.
	 * @return string[] Filtered ability names.
	 */
	public function filter_ability_names( array $names ): array {
		$disabled = get_option( self::OPTION_DISABLED_TOOLS, array() );

		if ( empty( $disabled ) ) {
			return $names;
		}

		return array_values( array_diff( $names, $disabled ) );
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'setup'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tabs       = array(
			'setup'      => __( 'Setup', 'mindcrafts-ai' ),
			'tools'      => __( 'Tools', 'mindcrafts-ai' ),
			'connection' => __( 'Connection', 'mindcrafts-ai' ),
		);

		if ( ! isset( $tabs[ $active_tab ] ) ) {
			$active_tab = 'setup';
		}

		?>
		<div class="wrap mindcrafts-ai-admin">
			<h1><?php esc_html_e( 'MindCrafts AI', 'mindcrafts-ai' ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&tab=' . $tab_key ) ); ?>"
					   class="nav-tab <?php echo esc_attr( $tab_key === $active_tab ? 'nav-tab-active' : '' ); ?>">
						<?php echo esc_html( $tab_label ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="tab-content">
				<?php
				if ( 'connection' === $active_tab ) {
					include MINDCRAFTS_AI_DIR . 'includes/admin/views/page-connection.php';
				} elseif ( 'tools' === $active_tab ) {
					include MINDCRAFTS_AI_DIR . 'includes/admin/views/page-tools.php';
				} else {
					include MINDCRAFTS_AI_DIR . 'includes/admin/views/page-setup.php';
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Get required dependency definitions for setup checks and installer actions.
	 *
	 * @since 2.0.0
	 *
	 * @return array<string, array<string, mixed>> Dependency definitions.
	 */
	public function get_dependency_definitions(): array {
		return array(
			'elementor'     => array(
				'label'          => __( 'Elementor', 'mindcrafts-ai' ),
				'description'    => __( 'Required page builder. MindCrafts AI reads and writes Elementor documents, widgets, containers, and templates.', 'mindcrafts-ai' ),
				'is_active'      => did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ),
				'plugin_files'   => array( 'elementor/elementor.php' ),
				'name_matches'   => array( 'Elementor' ),
				'download_url'   => 'https://downloads.wordpress.org/plugin/elementor.latest-stable.zip',
				'installable'    => true,
				'source_label'   => __( 'WordPress.org', 'mindcrafts-ai' ),
				'manual_message' => '',
			),
			'mcp_adapter'  => array(
				'label'          => __( 'WordPress MCP Adapter', 'mindcrafts-ai' ),
				'description'    => __( 'Required bridge that exposes WordPress Abilities as MCP tools for AI clients.', 'mindcrafts-ai' ),
				'is_active'      => class_exists( '\WP\MCP\Core\McpAdapter' ),
				'plugin_files'   => array(
					'mcp-adapter/mcp-adapter.php',
					'wordpress-mcp-adapter/mcp-adapter.php',
				),
				'name_matches'   => array( 'MCP Adapter', 'WordPress MCP Adapter' ),
				'download_url'   => 'https://github.com/WordPress/mcp-adapter/releases/download/v0.5.0/mcp-adapter.zip',
				'installable'    => true,
				'source_label'   => __( 'Official GitHub release', 'mindcrafts-ai' ),
				'manual_message' => '',
			),
			'abilities_api' => array(
				'label'          => __( 'WordPress Abilities API', 'mindcrafts-ai' ),
				'description'    => __( 'Required API used to register MindCrafts AI tools before the MCP Adapter exposes them.', 'mindcrafts-ai' ),
				'is_active'      => function_exists( 'wp_register_ability' ),
				'plugin_files'   => array(
					'abilities-api/abilities-api.php',
					'wordpress-abilities-api/abilities-api.php',
				),
				'name_matches'   => array( 'Abilities API', 'WordPress Abilities API' ),
				'download_url'   => '',
				'installable'    => false,
				'source_label'   => __( 'WordPress core or official package', 'mindcrafts-ai' ),
				'manual_message' => __( 'If this is missing, update WordPress to a build that includes the Abilities API or install the official Abilities API package used by the MCP Adapter.', 'mindcrafts-ai' ),
			),
		);
	}

	/**
	 * Get current status for one dependency.
	 *
	 * @since 2.0.0
	 *
	 * @param string $dependency_key Dependency key.
	 * @return array{definition: array<string, mixed>, plugin_file: string, is_installed: bool, is_active: bool}
	 */
	public function get_dependency_status( string $dependency_key ): array {
		$definitions = $this->get_dependency_definitions();
		$definition  = isset( $definitions[ $dependency_key ] ) ? $definitions[ $dependency_key ] : array();
		$plugin_file = $definition ? $this->get_plugin_file_for_dependency( $definition ) : '';
		$is_active   = ! empty( $definition['is_active'] );

		if ( ! $is_active && $plugin_file ) {
			$this->load_plugin_admin_functions();
			$is_active = is_plugin_active( $plugin_file );
		}

		return array(
			'definition'   => $definition,
			'plugin_file'  => $plugin_file,
			'is_installed' => '' !== $plugin_file,
			'is_active'    => $is_active,
		);
	}

	/**
	 * Install a required dependency from a trusted source and activate it when possible.
	 *
	 * @since 2.0.0
	 */
	public function handle_dependency_install(): void {
		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to install plugins.', 'mindcrafts-ai' ) );
		}

		$dependency_key = isset( $_POST['dependency'] ) ? sanitize_key( wp_unslash( $_POST['dependency'] ) ) : '';
		check_admin_referer( 'mindcrafts_ai_dependency_' . $dependency_key, 'mindcrafts_ai_nonce' );

		$definitions = $this->get_dependency_definitions();
		if ( ! isset( $definitions[ $dependency_key ] ) || empty( $definitions[ $dependency_key ]['installable'] ) || empty( $definitions[ $dependency_key ]['download_url'] ) ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'install_not_supported',
				)
			);
		}

		$status = $this->get_dependency_status( $dependency_key );
		if ( $status['is_active'] ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'already_active',
				)
			);
		}

		$this->load_plugin_admin_functions();
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

		$skin     = new Automatic_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->install( esc_url_raw( $definitions[ $dependency_key ]['download_url'] ) );

		if ( is_wp_error( $result ) || ! $result ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'install_failed',
				)
			);
		}

		$plugin_file = $this->get_plugin_file_for_dependency( $definitions[ $dependency_key ] );

		if ( $plugin_file && current_user_can( 'activate_plugins' ) ) {
			$activation_result = activate_plugin( $plugin_file );
			if ( is_wp_error( $activation_result ) ) {
				$this->redirect_to_setup(
					array(
						'dependency'        => $dependency_key,
						'dependency_result' => 'activate_failed',
					)
				);
			}
		}

		$this->redirect_to_setup(
			array(
				'dependency'        => $dependency_key,
				'dependency_result' => 'installed',
			)
		);
	}

	/**
	 * Activate an already installed dependency.
	 *
	 * @since 2.0.0
	 */
	public function handle_dependency_activate(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to activate plugins.', 'mindcrafts-ai' ) );
		}

		$dependency_key = isset( $_POST['dependency'] ) ? sanitize_key( wp_unslash( $_POST['dependency'] ) ) : '';
		check_admin_referer( 'mindcrafts_ai_dependency_' . $dependency_key, 'mindcrafts_ai_nonce' );

		$definitions = $this->get_dependency_definitions();
		if ( ! isset( $definitions[ $dependency_key ] ) ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'unknown_dependency',
				)
			);
		}

		$plugin_file = $this->get_plugin_file_for_dependency( $definitions[ $dependency_key ] );
		if ( ! $plugin_file ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'not_installed',
				)
			);
		}

		$result = activate_plugin( $plugin_file );
		if ( is_wp_error( $result ) ) {
			$this->redirect_to_setup(
				array(
					'dependency'        => $dependency_key,
					'dependency_result' => 'activate_failed',
				)
			);
		}

		$this->redirect_to_setup(
			array(
				'dependency'        => $dependency_key,
				'dependency_result' => 'activated',
			)
		);
	}

	/**
	 * Find the installed plugin file for a dependency.
	 *
	 * @since 2.0.0
	 *
	 * @param array<string, mixed> $definition Dependency definition.
	 * @return string Plugin file path relative to the plugins directory, or empty string.
	 */
	private function get_plugin_file_for_dependency( array $definition ): string {
		$this->load_plugin_admin_functions();

		$plugins = get_plugins();

		foreach ( (array) $definition['plugin_files'] as $plugin_file ) {
			if ( isset( $plugins[ $plugin_file ] ) ) {
				return $plugin_file;
			}
		}

		foreach ( $plugins as $plugin_file => $plugin_data ) {
			foreach ( (array) $definition['name_matches'] as $name_match ) {
				if ( ! empty( $plugin_data['Name'] ) && false !== stripos( $plugin_data['Name'], $name_match ) ) {
					return $plugin_file;
				}
			}
		}

		return '';
	}

	/**
	 * Load admin plugin helpers when they are needed.
	 *
	 * @since 2.0.0
	 */
	private function load_plugin_admin_functions(): void {
		if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_plugin_active' ) || ! function_exists( 'activate_plugin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	}

	/**
	 * Redirect back to the Setup tab.
	 *
	 * @since 2.0.0
	 *
	 * @param array<string, string> $args Query arguments.
	 */
	private function redirect_to_setup( array $args = array() ): void {
		wp_safe_redirect(
			add_query_arg(
				array_merge(
					array(
						'page' => self::PAGE_SLUG,
						'tab'  => 'setup',
					),
					$args
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Get all tools grouped by category for the UI.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string, array{label: string, tools: array<string, array{label: string, description: string, badges: string[]}>}> Grouped tools.
	 */
	public function get_all_tools(): array {
		return array(
			'query'            => array(
				'label' => __( 'Query & Discovery', 'mindcrafts-ai' ),
				'tools' => array(
					'mindcrafts-ai/list-widgets'         => array(
						'label'       => __( 'List Widgets', 'mindcrafts-ai' ),
						'description' => __( 'Lists all available Elementor widget types and their names.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/get-widget-schema'    => array(
						'label'       => __( 'Get Widget Schema', 'mindcrafts-ai' ),
						'description' => __( 'Returns the JSON schema for a specific widget type.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/get-page-structure'   => array(
						'label'       => __( 'Get Page Structure', 'mindcrafts-ai' ),
						'description' => __( 'Returns the full Elementor element tree for a page.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/get-element-settings' => array(
						'label'       => __( 'Get Element Settings', 'mindcrafts-ai' ),
						'description' => __( 'Returns the settings of a specific element by ID.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/list-pages'           => array(
						'label'       => __( 'List Pages', 'mindcrafts-ai' ),
						'description' => __( 'Lists all pages/posts that use Elementor.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/list-templates'       => array(
						'label'       => __( 'List Templates', 'mindcrafts-ai' ),
						'description' => __( 'Lists all saved Elementor templates.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/get-global-settings'  => array(
						'label'       => __( 'Get Global Settings', 'mindcrafts-ai' ),
						'description' => __( 'Returns global colors, typography, and theme settings.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
				),
			),
			'page'             => array(
				'label' => __( 'Page Management', 'mindcrafts-ai' ),
				'tools' => array(
					'mindcrafts-ai/create-page'          => array(
						'label'       => __( 'Create Page', 'mindcrafts-ai' ),
						'description' => __( 'Creates a new WordPress page with Elementor enabled.', 'mindcrafts-ai' ),
						'badges'      => array(),
					),
					'mindcrafts-ai/update-page-settings' => array(
						'label'       => __( 'Update Page Settings', 'mindcrafts-ai' ),
						'description' => __( 'Updates Elementor page-level settings (layout, canvas, etc).', 'mindcrafts-ai' ),
						'badges'      => array(),
					),
					'mindcrafts-ai/delete-page-content'  => array(
						'label'       => __( 'Delete Page Content', 'mindcrafts-ai' ),
						'description' => __( 'Removes all Elementor content from a page.', 'mindcrafts-ai' ),
						'badges'      => array( 'destructive' ),
					),
						'description' => __( 'Creates a complete page from a declarative structure in one call.', 'mindcrafts-ai' ),
						'badges'      => array(),
					),
				),
			),
			'stock_images'     => array(
				'label' => __( 'Stock Images', 'mindcrafts-ai' ),
				'tools' => array(
					'mindcrafts-ai/search-images'    => array(
						'label'       => __( 'Search Images', 'mindcrafts-ai' ),
						'description' => __( 'Searches Openverse for Creative Commons licensed images.', 'mindcrafts-ai' ),
						'badges'      => array( 'read-only' ),
					),
					'mindcrafts-ai/sideload-image'   => array(
						'label'       => __( 'Sideload Image', 'mindcrafts-ai' ),
						'description' => __( 'Downloads an external image into the WordPress Media Library.', 'mindcrafts-ai' ),
						'badges'      => array(),
					),
					'mindcrafts-ai/add-stock-image'  => array(
						'label'       => __( 'Add Stock Image', 'mindcrafts-ai' ),
						'description' => __( 'Searches, downloads, and adds a stock image to the page in one call.', 'mindcrafts-ai' ),
						'badges'      => array(),
					),
				),
			),
		);
	}

	/**
	 * Get a flat list of all tool slugs.
	 *
	 * @since 1.0.0
	 *
	 * @return string[] All tool slugs.
	 */
	public function get_all_tool_slugs(): array {
		$slugs = array();

		foreach ( $this->get_all_tools() as $category ) {
			foreach ( $category['tools'] as $slug => $tool ) {
				$slugs[] = $slug;
			}
		}

		return $slugs;
	}

	/**
	 * Count enabled tools.
	 *
	 * @since 1.0.0
	 *
	 * @return int Number of enabled tools.
	 */
	public function get_enabled_tool_count(): int {
		$all      = $this->get_all_tool_slugs();
		$disabled = get_option( self::OPTION_DISABLED_TOOLS, array() );

		return count( array_diff( $all, $disabled ) );
	}

	/**
	 * Count total tools.
	 *
	 * @since 1.0.0
	 *
	 * @return int Total number of tools.
	 */
	public function get_total_tool_count(): int {
		return count( $this->get_all_tool_slugs() );
	}
}
