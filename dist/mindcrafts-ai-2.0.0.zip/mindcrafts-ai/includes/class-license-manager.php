<?php
/**
 * License Manager for MindCrafts AI Premium.
 *
 * @package MindCrafts_AI
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MindCrafts_AI_License_Manager {

	private static $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * Checks if the user has an active premium license.
	 *
	 * @return bool
	 */
	public function is_premium_active(): bool {
		$license = get_option( 'mindcrafts_ai_license_key', '' );
		$status  = get_option( 'mindcrafts_ai_license_status', 'invalid' );

		// For now, this is a placeholder. Real implementation will check against an API.
		return ( ! empty( $license ) && 'valid' === $status );
	}

	/**
	 * A generic permission callback for premium abilities.
	 * 
	 * @return bool
	 */
	public function check_premium_permission(): bool {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		
		return $this->is_premium_active();
	}
}
